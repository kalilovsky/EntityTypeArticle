<?php

declare(strict_types=1);

namespace Doctrine\ORM\Exception;

use Throwable;

interface ConfigurationException extends Throwable
{
}
